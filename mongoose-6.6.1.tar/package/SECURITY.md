Please follow the instructions on [Tidelift's security page](https://tidelift.com/docs/security) to report a security issue.
